import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { creerRetrait } from '@/lib/psp';

export async function POST(request) {
  const body = await request.json().catch(() => null);
  const phone = (body?.phone || '').trim();
  const amount = Number(body?.amount);

  if (!phone) {
    return NextResponse.json({ error: 'Numéro de téléphone requis.' }, { status: 400 });
  }
  if (!Number.isFinite(amount) || amount <= 0) {
    return NextResponse.json({ error: 'Montant invalide.' }, { status: 400 });
  }

  const { reference, provider } = await creerRetrait({ phone, amount });

  try {
    const transaction = await prisma.$transaction(async (tx) => {
      const user = await tx.user.findUnique({ where: { phone } });

      if (!user || user.balance < amount) {
        throw new Error('SOLDE_INSUFFISANT');
      }

      // Le montant est réservé (débité) immédiatement, de façon atomique,
      // pour empêcher un double retrait qui dépasserait le solde réel.
      await tx.user.update({
        where: { id: user.id },
        data: { balance: { decrement: amount } },
      });

      return tx.transaction.create({
        data: {
          reference,
          type: 'RETRAIT',
          status: 'EN_ATTENTE',
          amount,
          phone,
          userId: user.id,
          provider,
        },
      });
    });

    return NextResponse.json({ reference: transaction.reference }, { status: 201 });
  } catch (err) {
    if (err.message === 'SOLDE_INSUFFISANT') {
      return NextResponse.json({ error: 'Solde insuffisant pour ce retrait.' }, { status: 400 });
    }
    console.error('Erreur création retrait :', err);
    return NextResponse.json({ error: 'Impossible de créer la demande de retrait.' }, { status: 500 });
  }
}

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { verifierStatutCinetPay } from '@/lib/psp';

export async function POST(request) {
  // CinetPay envoie le notify_url soit en JSON, soit en x-www-form-urlencoded
  // selon la configuration du compte marchand : on gère les deux.
  const contentType = request.headers.get('content-type') || '';
  let body;
  if (contentType.includes('application/json')) {
    body = await request.json().catch(() => ({}));
  } else {
    const form = await request.formData().catch(() => null);
    body = form ? Object.fromEntries(form.entries()) : {};
  }

  const reference = body.cpm_trans_id || body.transaction_id || body.reference;

  if (!reference) {
    return NextResponse.json({ error: 'Référence manquante.' }, { status: 400 });
  }

  const transaction = await prisma.transaction.findUnique({ where: { reference } });

  // On répond 200 même si la transaction est inconnue ou déjà traitée, pour
  // éviter que le PSP ne ré-essaie indéfiniment un webhook obsolète.
  if (!transaction || transaction.status !== 'EN_ATTENTE') {
    return NextResponse.json({ ok: true });
  }

  let accepte = false;
  try {
    accepte = await verifierStatutCinetPay(reference);
  } catch (err) {
    console.error('Erreur vérification statut CinetPay :', err);
    return NextResponse.json({ ok: false }, { status: 502 });
  }

  if (accepte) {
    await prisma.$transaction([
      prisma.transaction.update({ where: { id: transaction.id }, data: { status: 'VALIDEE' } }),
      prisma.user.update({
        where: { id: transaction.userId },
        data: { balance: { increment: transaction.amount } },
      }),
    ]);
  } else {
    await prisma.transaction.update({ where: { id: transaction.id }, data: { status: 'REJETEE' } });
  }

  return NextResponse.json({ ok: true });
}

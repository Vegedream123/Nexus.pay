import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET(request, { params }) {
  const transaction = await prisma.transaction.findUnique({
    where: { reference: params.ref },
  });

  if (!transaction) {
    return NextResponse.json({ error: 'Transaction introuvable.' }, { status: 404 });
  }

  return NextResponse.json({
    reference: transaction.reference,
    status: transaction.status,
    amount: transaction.amount,
    type: transaction.type,
    instructions: transaction.note,
  });
}

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { creerRecharge } from '@/lib/psp';

export async function POST(request) {
  const body = await request.json().catch(() => null);
  const phone = (body?.phone || '').trim();
  const amount = Number(body?.amount);

  if (!phone) {
    return NextResponse.json({ error: 'Numéro de téléphone requis.' }, { status: 400 });
  }
  if (!Number.isFinite(amount) || amount <= 0) {
    return NextResponse.json({ error: 'Montant invalide.' }, { status: 400 });
  }

  const user = await prisma.user.upsert({
    where: { phone },
    update: {},
    create: { phone, balance: 0 },
  });

  let resultatPsp;
  try {
    resultatPsp = await creerRecharge({ phone, amount });
  } catch (err) {
    console.error('Erreur création recharge PSP :', err);
    return NextResponse.json(
      { error: err.message || 'Le prestataire de paiement est indisponible.' },
      { status: 502 }
    );
  }

  const transaction = await prisma.transaction.create({
    data: {
      reference: resultatPsp.reference,
      type: 'RECHARGE',
      status: 'EN_ATTENTE',
      amount,
      phone,
      userId: user.id,
      provider: resultatPsp.provider,
      paymentUrl: resultatPsp.paymentUrl,
      note: resultatPsp.instructions,
    },
  });

  return NextResponse.json(
    {
      reference: transaction.reference,
      paymentUrl: transaction.paymentUrl,
      instructions: transaction.note,
    },
    { status: 201 }
  );
}

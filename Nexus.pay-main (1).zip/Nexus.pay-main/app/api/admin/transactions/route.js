import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { estAdminConnecte } from '@/lib/admin-auth';

export async function GET(request) {
  if (!estAdminConnecte()) {
    return NextResponse.json({ error: 'Non autorisé.' }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const status = searchParams.get('status') || 'EN_ATTENTE';
  const type = searchParams.get('type') || 'TOUS';

  const where = {};
  if (status !== 'TOUS') where.status = status;
  if (type !== 'TOUS') where.type = type;

  const transactions = await prisma.transaction.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: 100,
  });

  return NextResponse.json({ transactions });
}

import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { estAdminConnecte } from '@/lib/admin-auth';

export async function PATCH(request, { params }) {
  if (!estAdminConnecte()) {
    return NextResponse.json({ error: 'Non autorisé.' }, { status: 401 });
  }

  const body = await request.json().catch(() => null);
  const action = body?.action; // 'valider' | 'rejeter'

  if (!['valider', 'rejeter'].includes(action)) {
    return NextResponse.json({ error: 'Action invalide.' }, { status: 400 });
  }

  const transaction = await prisma.transaction.findUnique({ where: { id: params.id } });

  if (!transaction) {
    return NextResponse.json({ error: 'Transaction introuvable.' }, { status: 404 });
  }
  if (transaction.status !== 'EN_ATTENTE') {
    return NextResponse.json({ error: 'Cette transaction a déjà été traitée.' }, { status: 409 });
  }

  const nouveauStatut = action === 'valider' ? 'VALIDEE' : 'REJETEE';

  if (transaction.type === 'RECHARGE' && action === 'valider') {
    // La recharge n'avait encore jamais crédité le solde : on le fait ici,
    // au moment de la validation manuelle par l'admin.
    await prisma.$transaction([
      prisma.transaction.update({ where: { id: transaction.id }, data: { status: nouveauStatut } }),
      prisma.user.update({
        where: { id: transaction.userId },
        data: { balance: { increment: transaction.amount } },
      }),
    ]);
  } else if (transaction.type === 'RETRAIT' && action === 'rejeter') {
    // Le montant avait été réservé (débité) dès la demande : on le rembourse.
    await prisma.$transaction([
      prisma.transaction.update({ where: { id: transaction.id }, data: { status: nouveauStatut } }),
      prisma.user.update({
        where: { id: transaction.userId },
        data: { balance: { increment: transaction.amount } },
      }),
    ]);
  } else {
    // RECHARGE rejetée (jamais créditée, rien à annuler) ou RETRAIT validé
    // (l'admin a déjà physiquement envoyé l'argent avant de cliquer).
    await prisma.transaction.update({ where: { id: transaction.id }, data: { status: nouveauStatut } });
  }

  return NextResponse.json({ ok: true });
}

'use client';

import { Suspense, useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import StatusBadge from '@/components/StatusBadge';

const INTERVALLE_MS = 4000;

function ConfirmationContenu() {
  const searchParams = useSearchParams();
  const reference = searchParams.get('ref');

  const [transaction, setTransaction] = useState(null);
  const [erreur, setErreur] = useState('');
  const intervalRef = useRef(null);

  useEffect(() => {
    if (!reference) return;

    async function verifier() {
      try {
        const res = await fetch(`/api/recharge/${reference}`, { cache: 'no-store' });
        const data = await res.json();

        if (!res.ok) {
          setErreur(data.error || 'Transaction introuvable.');
          clearInterval(intervalRef.current);
          return;
        }

        setTransaction(data);

        if (data.status !== 'EN_ATTENTE') {
          clearInterval(intervalRef.current);
        }
      } catch (err) {
        // Une erreur réseau ponctuelle ne doit pas arrêter le suivi : on
        // réessaiera au prochain intervalle.
      }
    }

    verifier();
    intervalRef.current = setInterval(verifier, INTERVALLE_MS);
    return () => clearInterval(intervalRef.current);
  }, [reference]);

  if (!reference) {
    return (
      <div className="card">
        <p className="field-error">Référence de transaction manquante.</p>
        <Link href="/recharge" className="btn btn-outline btn-block" style={{ marginTop: 16 }}>
          Faire une nouvelle recharge
        </Link>
      </div>
    );
  }

  return (
    <div className="card">
      {erreur ? (
        <p className="field-error">{erreur}</p>
      ) : !transaction ? (
        <p className="text-muted pulse">Recherche de votre transaction…</p>
      ) : (
        <>
          <StatusBadge status={transaction.status} />
          <div className="confirmation-amount">
            {Number(transaction.amount).toLocaleString('fr-FR')} FCFA
          </div>

          {transaction.status === 'EN_ATTENTE' && (
            <p className="text-muted pulse" style={{ marginTop: 14 }}>
              Vérification en cours — cette page se met à jour automatiquement.
            </p>
          )}
          {transaction.status === 'VALIDEE' && (
            <p className="text-muted" style={{ marginTop: 14, color: 'var(--primary-dark)' }}>
              Recharge confirmée, votre solde a été crédité.
            </p>
          )}
          {transaction.status === 'REJETEE' && (
            <p className="text-muted" style={{ marginTop: 14, color: 'var(--danger)' }}>
              Cette recharge n'a pas pu être validée. Contactez le support si le
              montant a bien été envoyé.
            </p>
          )}

          {transaction.instructions && transaction.status === 'EN_ATTENTE' && (
            <div className="instructions-box">{transaction.instructions}</div>
          )}

          <div className="confirmation-ref">Référence : {transaction.reference}</div>
        </>
      )}

      <Link href="/" className="btn btn-outline btn-block" style={{ marginTop: 22 }}>
        Retour à l'accueil
      </Link>
    </div>
  );
}

export default function ConfirmationPage() {
  return (
    <main className="page">
      <div className="page-narrow">
        <span className="eyebrow">Recharge</span>
        <h1 className="title-md" style={{ marginTop: 6, marginBottom: 20 }}>Suivi de votre recharge</h1>

        <Suspense fallback={<p className="text-muted">Chargement…</p>}>
          <ConfirmationContenu />
        </Suspense>
      </div>
    </main>
  );
}

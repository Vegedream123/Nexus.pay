'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function RechargePage() {
  const router = useRouter();
  const [phone, setPhone] = useState('');
  const [amount, setAmount] = useState('');
  const [erreur, setErreur] = useState('');
  const [envoi, setEnvoi] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    setErreur('');

    const montantNombre = Number(amount);
    if (!phone.trim()) {
      setErreur('Entrez votre numéro de téléphone.');
      return;
    }
    if (!Number.isFinite(montantNombre) || montantNombre <= 0) {
      setErreur('Entrez un montant valide.');
      return;
    }

    setEnvoi(true);
    try {
      const res = await fetch('/api/recharge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: phone.trim(), amount: montantNombre }),
      });
      const data = await res.json();

      if (!res.ok) {
        setErreur(data.error || "Une erreur est survenue.");
        setEnvoi(false);
        return;
      }

      if (data.paymentUrl) {
        // Mode PSP automatique : on part payer chez le prestataire.
        window.location.href = data.paymentUrl;
        return;
      }

      // Mode manuel : on va sur la page de suivi.
      router.push(`/recharge/confirmation?ref=${data.reference}`);
    } catch (err) {
      setErreur('Impossible de contacter le serveur. Réessayez.');
      setEnvoi(false);
    }
  }

  return (
    <main className="page">
      <div className="page-narrow">
        <Link href="/" className="back-link">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6" /></svg>
          Accueil
        </Link>

        <span className="eyebrow">Recharge</span>
        <h1 className="title-md" style={{ marginTop: 6 }}>Créditer votre solde</h1>

        <form className="card" style={{ marginTop: 20 }} onSubmit={onSubmit}>
          <div className="field">
            <label htmlFor="phone">Numéro de téléphone</label>
            <input
              id="phone"
              type="tel"
              inputMode="tel"
              placeholder="Ex : 6 90 00 00 00"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              autoComplete="tel"
            />
          </div>

          <div className="field">
            <label htmlFor="amount">Montant (FCFA)</label>
            <input
              id="amount"
              type="number"
              inputMode="numeric"
              min="1"
              placeholder="Ex : 5000"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>

          {erreur && <p className="field-error" style={{ marginBottom: 16 }}>{erreur}</p>}

          <button type="submit" className="btn btn-primary btn-block" disabled={envoi}>
            {envoi ? 'Traitement…' : 'Continuer'}
          </button>
        </form>
      </div>
    </main>
  );
}

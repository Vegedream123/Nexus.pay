'use client';

import { useCallback, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import StatusBadge from '@/components/StatusBadge';

const STATUTS = [
  { value: 'EN_ATTENTE', label: 'En attente' },
  { value: 'VALIDEE', label: 'Validées' },
  { value: 'REJETEE', label: 'Rejetées' },
  { value: 'TOUS', label: 'Toutes' },
];

const TYPES = [
  { value: 'TOUS', label: 'Tous types' },
  { value: 'RECHARGE', label: 'Recharges' },
  { value: 'RETRAIT', label: 'Retraits' },
];

export default function AdminDashboard() {
  const router = useRouter();
  const [status, setStatus] = useState('EN_ATTENTE');
  const [type, setType] = useState('TOUS');
  const [transactions, setTransactions] = useState([]);
  const [chargement, setChargement] = useState(true);
  const [enCours, setEnCours] = useState(null);

  const charger = useCallback(async () => {
    setChargement(true);
    const params = new URLSearchParams({ status, type });
    const res = await fetch(`/api/admin/transactions?${params}`, { cache: 'no-store' });

    if (res.status === 401) {
      router.push('/admin/login');
      return;
    }

    const data = await res.json();
    setTransactions(data.transactions || []);
    setChargement(false);
  }, [status, type, router]);

  useEffect(() => {
    charger();
  }, [charger]);

  async function agir(id, action) {
    setEnCours(id);
    try {
      const res = await fetch(`/api/admin/transactions/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      if (res.ok) {
        setTransactions((prev) => prev.filter((t) => t.id !== id));
      }
    } finally {
      setEnCours(null);
    }
  }

  async function seDeconnecter() {
    await fetch('/api/admin/login', { method: 'DELETE' });
    router.push('/admin/login');
    router.refresh();
  }

  return (
    <main className="page">
      <div className="page-wide">
        <div className="admin-header">
          <div>
            <span className="eyebrow">NexusPay</span>
            <h1 className="title-md" style={{ marginTop: 4 }}>Transactions</h1>
          </div>
          <button className="btn btn-outline btn-sm" onClick={seDeconnecter}>
            Se déconnecter
          </button>
        </div>

        <div className="admin-filters">
          {STATUTS.map((s) => (
            <button
              key={s.value}
              className={`pill-toggle ${status === s.value ? 'active' : ''}`}
              onClick={() => setStatus(s.value)}
            >
              {s.label}
            </button>
          ))}
        </div>
        <div className="admin-filters">
          {TYPES.map((t) => (
            <button
              key={t.value}
              className={`pill-toggle ${type === t.value ? 'active' : ''}`}
              onClick={() => setType(t.value)}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="admin-table-wrap">
          {chargement ? (
            <div className="admin-empty">Chargement…</div>
          ) : transactions.length === 0 ? (
            <div className="admin-empty">Aucune transaction pour ces filtres.</div>
          ) : (
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Type</th>
                  <th>Téléphone</th>
                  <th>Montant</th>
                  <th>Référence</th>
                  <th>Statut</th>
                  <th>Reçue le</th>
                  {status === 'EN_ATTENTE' && <th>Actions</th>}
                </tr>
              </thead>
              <tbody>
                {transactions.map((t) => (
                  <tr key={t.id} className={`admin-row-flag status-${t.status}-row`}>
                    <td data-label="Type">{t.type === 'RECHARGE' ? 'Recharge' : 'Retrait'}</td>
                    <td data-label="Téléphone" className="data">{t.phone}</td>
                    <td data-label="Montant" className="data">{Number(t.amount).toLocaleString('fr-FR')} FCFA</td>
                    <td data-label="Référence" className="data">{t.reference}</td>
                    <td data-label="Statut"><StatusBadge status={t.status} /></td>
                    <td data-label="Reçue le">
                      {new Date(t.createdAt).toLocaleString('fr-FR', {
                        day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit',
                      })}
                    </td>
                    {status === 'EN_ATTENTE' && (
                      <td data-label="Actions">
                        <div className="admin-actions">
                          <button
                            className="btn btn-primary btn-sm"
                            disabled={enCours === t.id}
                            onClick={() => agir(t.id, 'valider')}
                          >
                            Valider
                          </button>
                          <button
                            className="btn btn-danger-outline btn-sm"
                            disabled={enCours === t.id}
                            onClick={() => agir(t.id, 'rejeter')}
                          >
                            Rejeter
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </main>
  );
}

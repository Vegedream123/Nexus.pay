import { redirect } from 'next/navigation';
import { estAdminConnecte } from '@/lib/admin-auth';
import AdminDashboard from './AdminDashboard';

export default function AdminPage() {
  if (!estAdminConnecte()) {
    redirect('/admin/login');
  }

  return <AdminDashboard />;
}

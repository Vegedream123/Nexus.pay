'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function AdminLoginPage() {
  const router = useRouter();
  const [password, setPassword] = useState('');
  const [erreur, setErreur] = useState('');
  const [envoi, setEnvoi] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    setErreur('');
    setEnvoi(true);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      const data = await res.json();

      if (!res.ok) {
        setErreur(data.error || 'Mot de passe incorrect.');
        setEnvoi(false);
        return;
      }

      router.push('/admin');
      router.refresh();
    } catch (err) {
      setErreur('Impossible de contacter le serveur. Réessayez.');
      setEnvoi(false);
    }
  }

  return (
    <main className="login-shell">
      <div className="login-card">
        <span className="eyebrow">NexusPay</span>
        <h1 className="title-md" style={{ marginTop: 6, marginBottom: 20 }}>Administration</h1>

        <form className="card" onSubmit={onSubmit}>
          <div className="field">
            <label htmlFor="password">Mot de passe</label>
            <input
              id="password"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoFocus
            />
          </div>

          {erreur && <p className="field-error" style={{ marginBottom: 16 }}>{erreur}</p>}

          <button type="submit" className="btn btn-primary btn-block" disabled={envoi}>
            {envoi ? 'Connexion…' : 'Se connecter'}
          </button>
        </form>
      </div>
    </main>
  );
}

'use client';

import { useState } from 'react';
import Link from 'next/link';
import StatusBadge from '@/components/StatusBadge';

export default function RetraitPage() {
  const [phone, setPhone] = useState('');
  const [amount, setAmount] = useState('');
  const [erreur, setErreur] = useState('');
  const [envoi, setEnvoi] = useState(false);
  const [confirmation, setConfirmation] = useState(null);

  async function onSubmit(e) {
    e.preventDefault();
    setErreur('');

    const montantNombre = Number(amount);
    if (!phone.trim()) {
      setErreur('Entrez votre numéro de téléphone.');
      return;
    }
    if (!Number.isFinite(montantNombre) || montantNombre <= 0) {
      setErreur('Entrez un montant valide.');
      return;
    }

    setEnvoi(true);
    try {
      const res = await fetch('/api/retrait', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: phone.trim(), amount: montantNombre }),
      });
      const data = await res.json();

      if (!res.ok) {
        setErreur(data.error || 'Une erreur est survenue.');
        setEnvoi(false);
        return;
      }

      setConfirmation({ reference: data.reference, amount: montantNombre });
    } catch (err) {
      setErreur('Impossible de contacter le serveur. Réessayez.');
      setEnvoi(false);
    }
  }

  return (
    <main className="page">
      <div className="page-narrow">
        <Link href="/" className="back-link">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6" /></svg>
          Accueil
        </Link>

        <span className="eyebrow">Retrait</span>
        <h1 className="title-md" style={{ marginTop: 6 }}>Demander un retrait</h1>

        {confirmation ? (
          <div className="card" style={{ marginTop: 20 }}>
            <StatusBadge status="EN_ATTENTE" />
            <div className="confirmation-amount">
              {confirmation.amount.toLocaleString('fr-FR')} FCFA
            </div>
            <p className="text-muted" style={{ marginTop: 14 }}>
              Votre demande a été enregistrée. Le montant a été réservé sur
              votre solde et vous sera envoyé après vérification par un
              administrateur.
            </p>
            <div className="confirmation-ref">Référence : {confirmation.reference}</div>
            <Link href="/" className="btn btn-outline btn-block" style={{ marginTop: 22 }}>
              Retour à l'accueil
            </Link>
          </div>
        ) : (
          <form className="card" style={{ marginTop: 20 }} onSubmit={onSubmit}>
            <div className="field">
              <label htmlFor="phone">Numéro de téléphone</label>
              <input
                id="phone"
                type="tel"
                inputMode="tel"
                placeholder="Ex : 6 90 00 00 00"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                autoComplete="tel"
              />
            </div>

            <div className="field">
              <label htmlFor="amount">Montant à retirer (FCFA)</label>
              <input
                id="amount"
                type="number"
                inputMode="numeric"
                min="1"
                placeholder="Ex : 5000"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <span className="field-help">Ce montant sera réservé sur votre solde dès l'envoi.</span>
            </div>

            {erreur && <p className="field-error" style={{ marginBottom: 16 }}>{erreur}</p>}

            <button type="submit" className="btn btn-primary btn-block" disabled={envoi}>
              {envoi ? 'Envoi…' : 'Demander le retrait'}
            </button>
          </form>
        )}
      </div>
    </main>
  );
}

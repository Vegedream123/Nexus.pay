import Link from 'next/link';

export default function AccueilPage() {
  return (
    <main className="page">
      <div className="page-narrow">
        <span className="eyebrow">NexusPay</span>
        <h1 className="title-lg">Rechargez ou retirez votre solde en quelques minutes.</h1>
        <p className="text-muted" style={{ marginTop: 10 }}>
          Indiquez simplement votre numéro et le montant — vous suivez ensuite
          l'état de votre opération en direct.
        </p>

        <nav className="action-grid" aria-label="Actions principales">
          <Link href="/recharge" className="action-card">
            <span className="action-card-bar" />
            <span className="action-card-body">
              <span className="action-card-title">Recharger mon compte</span>
              <span className="action-card-sub">Créditer votre solde par Mobile Money</span>
            </span>
            <span className="action-card-arrow" aria-hidden="true">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6" /></svg>
            </span>
          </Link>

          <Link href="/retrait" className="action-card">
            <span className="action-card-bar warn" />
            <span className="action-card-body">
              <span className="action-card-title">Faire un retrait</span>
              <span className="action-card-sub">Retirer une partie de votre solde</span>
            </span>
            <span className="action-card-arrow" aria-hidden="true">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6" /></svg>
            </span>
          </Link>
        </nav>

        <div className="steps">
          <div className="step">
            <span className="step-index">1</span>
            <span className="step-text">Entrez votre numéro et le montant souhaité.</span>
          </div>
          <div className="step">
            <span className="step-index">2</span>
            <span className="step-text">Effectuez le paiement indiqué (Mobile Money).</span>
          </div>
          <div className="step">
            <span className="step-index">3</span>
            <span className="step-text">Votre solde est mis à jour dès validation.</span>
          </div>
        </div>
      </div>
    </main>
  );
}
